#!/usr/bin/env python3
"""
JARVIS Setup Script
Works on Windows and Fedora Linux.
"""

import sys
import platform
import subprocess
import os
from pathlib import Path

OS = platform.system()
PYTHON = sys.executable

def run(cmd: list, check=True):
    print(f"  → {' '.join(cmd)}")
    subprocess.run(cmd, check=check)

def banner(text: str):
    print(f"\n{'─'*50}")
    print(f"  {text}")
    print(f"{'─'*50}")

def check_python():
    banner("Checking Python version")
    v = sys.version_info
    if v < (3, 11):
        print(f"❌ Python 3.11+ required. You have {v.major}.{v.minor}")
        sys.exit(1)
    print(f"✅ Python {v.major}.{v.minor}.{v.micro}")

def install_system_deps():
    banner(f"Installing system dependencies ({OS})")
    if OS == "Linux":
        # Fedora/RHEL
        pkgs = ["portaudio-devel", "python3-devel", "gcc", "ffmpeg"]
        try:
            run(["sudo", "dnf", "install", "-y"] + pkgs)
        except Exception:
            # Ubuntu/Debian fallback
            run(["sudo", "apt-get", "install", "-y",
                 "portaudio19-dev", "python3-dev", "gcc", "ffmpeg"], check=False)
    elif OS == "Windows":
        # Check for chocolatey
        try:
            run(["choco", "install", "ffmpeg", "-y"], check=False)
        except FileNotFoundError:
            print("  ℹ  Install FFmpeg manually from https://ffmpeg.org/download.html")

def install_python_deps():
    banner("Installing Python dependencies")
    run([PYTHON, "-m", "pip", "install", "--upgrade", "pip"])
    run([PYTHON, "-m", "pip", "install", "-r", "requirements.txt"])

def setup_ollama():
    banner("Setting up Ollama (local AI)")
    print("  Ollama lets JARVIS run fully offline.")
    if OS == "Linux":
        print("  Install with: curl -fsSL https://ollama.com/install.sh | sh")
        print("  Then run: ollama pull llama3.2")
    elif OS == "Windows":
        print("  Download from: https://ollama.com/download/windows")
        print("  Then run: ollama pull llama3.2")

def create_env_file():
    banner("Creating .env template")
    env_path = Path(".env")
    if env_path.exists():
        print("  .env already exists, skipping.")
        return
    content = """# JARVIS API Keys — fill in the ones you have
# At minimum, set one AI provider key (or install Ollama for local AI)

ANTHROPIC_API_KEY=
OPENAI_API_KEY=
GROQ_API_KEY=
GOOGLE_API_KEY=
MISTRAL_API_KEY=
COHERE_API_KEY=
TOGETHER_API_KEY=
HUGGINGFACE_API_KEY=

TAVILY_API_KEY=
BRAVE_API_KEY=
SERPER_API_KEY=

ELEVENLABS_API_KEY=
DEEPGRAM_API_KEY=
"""
    env_path.write_text(content)
    print(f"  ✅ Created .env — add your API keys there.")

def create_memory_dir():
    banner("Creating JARVIS data directories")
    dirs = [
        Path.home() / ".jarvis" / "memory",
        Path.home() / ".jarvis" / "logs",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        print(f"  ✅ {d}")

def main():
    print("\n" + "═"*50)
    print("  🤖  JARVIS Setup Wizard")
    print("═"*50)
    print(f"  OS: {OS} {platform.release()}")

    check_python()
    install_system_deps()
    install_python_deps()
    setup_ollama()
    create_env_file()
    create_memory_dir()

    print("\n" + "═"*50)
    print("  ✅  JARVIS setup complete!")
    print("═"*50)
    print("\n  Next steps:")
    print("  1. Add your API keys to .env")
    print("  2. (Optional) Install Ollama for offline AI")
    print("  3. Run: python -m core.jarvis")
    print()

if __name__ == "__main__":
    main()
